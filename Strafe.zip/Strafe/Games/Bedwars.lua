local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")

local lEntity = Players.LocalPlayer

if not lEntity.Character then
    lEntity.CharacterAdded:Wait()
    repeat task.wait() until lEntity.Character

    lEntity.Character:WaitForChild('Humanoid', 999)
end

lEntity:WaitForChild('Settings')

local GuiLibrary = shared.GuiLibrary

local InventoryUtil = loadfile('Strafe/Libraries/Bedwars/InventoryUtil.lua')()
local fakeDamage = loadfile('Strafe/Libraries/FakeDamage.lua')()
local progressBar = loadfile('Strafe/Libraries/ProgressBar.lua')()
local entityLib = loadfile('Strafe/Libraries/Entity.lua')()
local Remotes = loadfile('Strafe/Libraries/Network.lua')()

local getNearestAttackable = function(Range: number, Method: string)
    Method = Method or 'Distance'

    local Nearest = nil
    local Data = math.huge

    for _, plr in Players:GetPlayers() do
        if plr == lEntity or plr.Team == lEntity.Team then continue end
        if not entityLib.getAlive(plr) or not entityLib.isAlive then continue end

        if Method == 'Distance' and lEntity:DistanceFromCharacter(plr.Character.PrimaryPart.Position) <= Range and lEntity:DistanceFromCharacter(plr.Character.PrimaryPart.Position) < Data then
            Nearest = plr
            Data = lEntity:DistanceFromCharacter(plr.Character.PrimaryPart.Position)
        elseif Method == 'Health' and plr.Character.Humanoid.Health < Data then
            Nearest = plr
            Data = plr.Character.Humanoid.Health
        end
    end
end

local switchHand = function(item: string)
    local rel = InventoryUtil:getRelativeItem(item)

    if not rel then
        return
    end

    return Remotes:Get('SetInvItem'):CallToServer({['hand'] = rel.tool})
end

local getRoundedPos = function(pos: Vector3)
    return Vector3.new(math.round(pos.X / 3), math.round(pos.Y / 3), math.round(pos.Z / 3))
end

local BlockMeta = {
    ['Wool'] = 1,
    ['Planks'] = 2,
    ['Stone'] = 3,
}

local getPlacingBlock = function()
    local best, val = nil, math.huge

    for ind, value in BlockMeta do
        if InventoryUtil:hasRelativeItem(ind) and value < val then
            best = ind
            val = value
        end
    end

    return best and InventoryUtil:getRelativeItem(best) or nil
end

local placeBlock = function(pos: Vector3)
    local rPos = getRoundedPos(pos)
    local Block = getPlacingBlock()

    if Block then
        Remotes:Get('PlaceBlock'):CallToServer({
            position = rPos,
            blockType = Block.itemType,
            blockData = 1,
        })

        local FakeBlock = Instance.new('Part')
        FakeBlock.Parent = workspace
        FakeBlock.Size = Vector3.new(3, 3, 3)
        FakeBlock.Anchored = true
        FakeBlock.CanQuery = false
        FakeBlock.CanTouch = false
        FakeBlock.Position = rPos

        task.delay(0.5, function()
            FakeBlock:Destroy()
            FakeBlock = nil
        end)

        return FakeBlock
    end
end

Longjump = GuiLibrary:registerModule({
    ['Name'] = 'Longjump',
    ['Window'] = 'Movement'
})